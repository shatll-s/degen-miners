#!/usr/bin/env bash

####################################################################################
###
### astylda miner
### Hive integration: shatll
###
####################################################################################
# allowed variables: WORKER_NAME CUSTOM_TEMPLATE CUSTOM_URL CUSTOM_PASS CUSTOM_ALGO CUSTOM_CONFIG_FILENAME
echo "WORKER_NAME =             $WORKER_NAME"
echo "CUSTOM_TEMPLATE =         $CUSTOM_TEMPLATE"
echo "CUSTOM_URL =              $CUSTOM_URL"
echo "CUSTOM_PASS =             $CUSTOM_PASS"
echo "CUSTOM_ALGO =             $CUSTOM_ALGO"
echo "CUSTOM_CONFIG_FILENAME =  $CUSTOM_CONFIG_FILENAME"
SCRIPT_DIR="$(dirname "$(readlink -f "$0")")"
. $SCRIPT_DIR/h-manifest.conf

echo "$SCRIPT_DIR/h-manifest.conf"
echo "WORKER_NAME =             $WORKER_NAME"
echo "CUSTOM_TEMPLATE =         $CUSTOM_TEMPLATE"
echo "CUSTOM_URL =              $CUSTOM_URL"
echo "CUSTOM_PASS =             $CUSTOM_PASS"
echo "CUSTOM_ALGO =             $CUSTOM_ALGO"
echo "CUSTOM_CONFIG_FILENAME =  $CUSTOM_CONFIG_FILENAME"

conf=
conf+=" --algo qhash"
conf+=" --url $CUSTOM_URL"
conf+=" --coinbase-addr $CUSTOM_TEMPLATE"
conf+=" --userpass $CUSTOM_PASS"

echo -e "$conf" > $CUSTOM_CONFIG_FILENAME

#miner='astylda'
#[[ -e /hive/custom ]] && . /hive/custom/$miner/h-manifest.conf
#[[ -e /hive/miners/custom ]] && . /hive/miners/custom/$miner/h-manifest.conf
#
#/hive/miners/custom/$miner/install.sh
#
#conf="-a $CUSTOM_TEMPLATE $CUSTOM_USER_CONFIG"
#echo -e "$conf" > $CUSTOM_CONFIG_FILENAME
