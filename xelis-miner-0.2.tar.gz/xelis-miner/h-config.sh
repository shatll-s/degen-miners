#!/usr/bin/env bash

####################################################################################
###
### xelis miner
### Hive integration: shatll
###
####################################################################################

[[ -e /hive/custom ]] && . /hive/custom/xelis-miner/h-manifest.conf
[[ -e /hive/miners/custom ]] && . /hive/miners/custom/xelis-miner/h-manifest.conf

/hive/miners/custom/xelis-miner/install.sh

conf="--host ${CUSTOM_URL} --wallet ${CUSTOM_TEMPLATE} ${CUSTOM_USER_CONFIG}"

echo -e "$conf" > $CUSTOM_CONFIG_FILENAME
