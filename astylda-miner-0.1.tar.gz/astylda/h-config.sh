#!/usr/bin/env bash

####################################################################################
###
### astylda miner
### Hive integration: shatll
###
####################################################################################

miner='astylda-miner'
[[ -e /hive/custom ]] && . /hive/custom/$miner/h-manifest.conf
[[ -e /hive/miners/custom ]] && . /hive/miners/custom/$miner/h-manifest.conf

/hive/miners/custom/astylda/install.sh
conf="-a $CUSTOM_TEMPLATE $CUSTOM_USER_CONFIG"
echo -e "$conf" > $CUSTOM_CONFIG_FILENAME
