#!/usr/bin/env bash

####################################################################################
###
### glytex miner for TARI
### Hive integration: shatll
###
####################################################################################

miner='glytex'
[[ -e /hive/custom ]] && . /hive/custom/$miner/h-manifest.conf
[[ -e /hive/miners/custom ]] && . /hive/miners/custom/$miner/h-manifest.conf

/hive/miners/custom/glytex/install.sh
conf="-a $CUSTOM_TEMPLATE --http-server-enabled true --http-server-port $WEB_PORT $CUSTOM_USER_CONFIG"
#conf="--host ${CUSTOM_URL} --wallet ${CUSTOM_TEMPLATE} ${CUSTOM_USER_CONFIG}"
#[[ "conf" != *"--display-hs-all"* ]] && conf+=" --display-hs-all"
echo -e "$conf" > $CUSTOM_CONFIG_FILENAME

#batch="./glytex -a $WALLET $args --http-server-enabled true --http-server-port $API_PORT"

#userCfg=""
#
#conf="SEED=$CUSTOM_TEMPLATE"
#[[ ! -z $CUSTOM_USER_CONFIG ]] && userCfg+=" $CUSTOM_USER_CONFIG"
#
#if [[ "$userCfg" == *"--uuid"* ]]; then
#  uuid=`echo $userCfg | sed -e 's/.*--uuid //; s/ .*//'`
#  [[ $uuid ]] && conf+="\nUUID=$uuid"
#  userCfg=`echo "$userCfg" | sed -e "s/--uuid $uuid//"`
#fi
#
#[[ $CUSTOM_PASS ]] && conf+="\nTONAPI_TOKEN=$CUSTOM_PASS"
#echo -e "$conf" > $CUSTOM_CONFIG_FILENAME
