#!/usr/bin/env bash

####################################################################################
###
### nock miner
### Hive integration: shatll
###
####################################################################################

cd `dirname $0`

[ -t 1 ] && . colors

. h-manifest.conf

echo "CUSTOM_NAME $CUSTOM_NAME"
echo "CUSTOM_LOG_BASENAME $CUSTOM_LOG_BASENAME"
echo "CUSTOM_CONFIG_FILENAME $CUSTOM_CONFIG_FILENAME"
echo "CUSTOM_NAME $CUSTOM_NAME"

[[ -z $CUSTOM_LOG_BASENAME ]] && echo -e "${RED}No CUSTOM_LOG_BASENAME is set${NOCOLOR}" && exit 1
[[ -z $CUSTOM_CONFIG_FILENAME ]] && echo -e "${RED}No CUSTOM_CONFIG_FILENAME is set${NOCOLOR}" && exit 1
[[ ! -f $CUSTOM_CONFIG_FILENAME ]] && echo -e "${RED}Custom config ${YELLOW}$CUSTOM_CONFIG_FILENAME${RED} is not found${NOCOLOR}" && exit 1


echo -e "${GREEN}> Starting $CUSTOM_MINERBIN${NOCOLOR}"
echo -e "${GREEN}> ./$CUSTOM_MINERBIN $(< $CUSTOM_CONFIG_FILENAME)${NOCOLOR}"

cpu=`expr $(nproc) / 2`
for (( i=0; i < ${cpu}; i++ )); do
  socket=nock$i.socket
  rm -f $socket
  batch="./$CUSTOM_MINERBIN $(< $CUSTOM_CONFIG_FILENAME) $@  --npc-socket=$socket"
  screen-kill nock$i
  RUST_LOG="slogger=info" screen -dmS nock$i bash -c "while true; do taskset -c $i  $batch; done"
done


#rm -rf nockchain.sock
#./$CUSTOM_MINERBIN $(< $CUSTOM_CONFIG_FILENAME) $@ --npc-socket nockchain.sock 2>&1 | tee $CUSTOM_LOG_BASENAME.log
