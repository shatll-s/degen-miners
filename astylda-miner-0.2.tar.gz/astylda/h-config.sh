#!/usr/bin/env bash

####################################################################################
###
### astylda miner
### Hive integration: shatll
###
####################################################################################

mkfile_from_symlink $CUSTOM_CONFIG_FILENAME

local user_config=`echo $CUSTOM_USER_CONFIG`

#generating config
echo "$user_config" > $CUSTOM_CONFIG_FILENAME

#miner='astylda'
#[[ -e /hive/custom ]] && . /hive/custom/$miner/h-manifest.conf
#[[ -e /hive/miners/custom ]] && . /hive/miners/custom/$miner/h-manifest.conf
#
#/hive/miners/custom/$miner/install.sh
#
#conf="-a $CUSTOM_TEMPLATE $CUSTOM_USER_CONFIG"
#echo -e "$conf" > $CUSTOM_CONFIG_FILENAME
