#!/usr/bin/env bash

####################################################################################
###
### astylda miner
### Hive integration: shatll
###
####################################################################################

cd `dirname $0`

[ -t 1 ] && . colors

. h-manifest.conf
cat $MINER_CONFIG_FILENAME
echo "#####################"
cat $CUSTOM_CONFIG_FILENAME
echo "#####################"

echo "CUSTOM_NAME $CUSTOM_NAME"
echo "CUSTOM_LOG_BASENAME $CUSTOM_LOG_BASENAME"
echo "CUSTOM_CONFIG_FILENAME $CUSTOM_CONFIG_FILENAME"
echo "CUSTOM_NAME $CUSTOM_NAME"

[[ -z $CUSTOM_LOG_BASENAME ]] && echo -e "${RED}No CUSTOM_LOG_BASENAME is set${NOCOLOR}" && exit 1
[[ -z $CUSTOM_CONFIG_FILENAME ]] && echo -e "${RED}No CUSTOM_CONFIG_FILENAME is set${NOCOLOR}" && exit 1
[[ ! -f $CUSTOM_CONFIG_FILENAME ]] && echo -e "${RED}Custom config ${YELLOW}$CUSTOM_CONFIG_FILENAME${RED} is not found${NOCOLOR}" && exit 1


echo -e "${GREEN}> Starting $CUSTOM_MINERBIN${NOCOLOR}"
echo -e "${GREEN}> ./$CUSTOM_MINERBIN $(< $CUSTOM_CONFIG_FILENAME)${NOCOLOR}"

#./$CUSTOM_MINERBIN $(< $CUSTOM_CONFIG_FILENAME) $@ 2>&1 | tee $CUSTOM_LOG_BASENAME.log


# parse args
parse_args() {
    local args="$1"
    shift
    local keys=("$@")

    read -ra tokens <<< "$args"
    local filtered=()

    for ((i = 0; i < ${#tokens[@]}; i++)); do
        local token="${tokens[i]}"
        local is_key=0

        for key in "${keys[@]}"; do
            if [[ "$token" == "--$key" ]]; then
                local var_name="${key//-/_}"

                if (( i + 1 < ${#tokens[@]} )); then
                    local value="${tokens[$((i+1))]}"
                    export "${var_name}=$value"
                else
                    export "${var_name}="
                fi

                ((i++))    # пропустить значение
                is_key=1
                break
            fi
        done

        if [[ $is_key -eq 0 ]]; then
            filtered+=("${token}")
        fi
    done


    echo "${filtered[*]}"
}

echo "> additional args: $ADDITION"
parse_args "$ADDITION" reserved_cores gpu_count
remainingAddition="${REPLY}"

echo "> remaining args: $remainingAddition"
echo "> using ${gpu_count} gpus"

[ -z "$reserved_cores" ] && reserved_cores=2
[ -z "$gpu_count" ] && gpu_count=$(gpu-detect NVIDIA)

$LINE
echo -e "${GREEN}> Starting custom miner:${WHITE}"

MY_PID=$$
total_cores=$(nproc)
usable_cores=$((total_cores - reserved_cores))
base_threads=$((usable_cores / gpu_count))
extra_threads=$((usable_cores % gpu_count))
echo "> using ${gpu_count} gpus"
for ((i = 0; i < gpu_count; i++)); do
  threads=$base_threads
  if (( i < extra_threads )); then
    threads=$((threads + 1))
  fi
  if (( threads < 1 )); then
    threads=1
  fi
  echo "> GPU $i → -t $threads"
  screenName="$CUSTOM_MINERBIN$i"
  apiPort="4444$i"
  log="/var/log/$CUSTOM_MINERBIN$i.log"
  batch="CUDA_VISIBLE_DEVICES=$i ./$CUSTOM_MINERBIN --algo qhash --url $CUSTOM_POOL --coinbase-addr $CUSTOM_TEMPLATE --userpass $CUSTOM_PASS -t $threads --api-bind $apiPort $remainingAddition"

  fullBatch=$(cat <<EOF
(
  ( while kill -0 $MY_PID 2>/dev/null; do sleep 1; done
    echo "GPU $i: parent died, shutting down miner..."
    kill \$\$ ) &

  while true; do $batch 2>&1 | tee -a $log; done
)
EOF
)

  echo "$batch"

  screen-kill $screenName
  screen -dmS "$screenName" bash -c "$fullBatch"
done

# for infinity
tail -f /dev/null
