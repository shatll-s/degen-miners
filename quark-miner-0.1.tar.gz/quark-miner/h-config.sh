#!/usr/bin/env bash

####################################################################################
###
### QUARK miner
### Hive integration: shatll
###
####################################################################################

[[ -e /hive/custom ]] && . /hive/custom/mrdn-miner/h-manifest.conf
[[ -e /hive/miners/custom ]] && . /hive/miners/custom/mrdn-miner/h-manifest.conf

/hive/miners/custom/mrdn-miner/install.sh

conf=""
conf2="SEED=$CUSTOM_TEMPLATE"

[[ ! -z $CUSTOM_USER_CONFIG ]] && conf+=" $CUSTOM_USER_CONFIG"

echo "$conf"
if [[ "$conf" == *"--uuid"* ]]; then
  target_address=`echo $conf | sed -e 's/.*--uuid //; s/ .*//'`
  [[ $target_address ]] && conf2+="\nUUID=$target_address"
  conf=`echo "$conf" | sed -e "s/--uuid $target_address//"`
fi

echo -e "$conf" > $CUSTOM_CONFIG_FILENAME

[[ $CUSTOM_PASS ]] && conf2+="\nTONAPI_TOKEN=$CUSTOM_PASS"
echo -e "$conf2" > $CUSTOM_CONFIG_FILENAME2
