#!/usr/bin/env bash

####################################################################################
###
### nock miner
### Hive integration: shatll
###
####################################################################################

miner='nock'
[[ -e /hive/custom ]] && . /hive/custom/$miner/h-manifest.conf
[[ -e /hive/miners/custom ]] && . /hive/miners/custom/$miner/h-manifest.conf

#/hive/miners/custom/glytex/install.sh
conf="$CUSTOM_USER_CONFIG"

echo -e "$conf" > $CUSTOM_CONFIG_FILENAME
