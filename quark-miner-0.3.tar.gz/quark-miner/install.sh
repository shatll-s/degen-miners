#!/usr/bin/env bash
[ -t 1 ] && . colors

function NeedToInstall() {
	local ver=`apt-cache policy $1 | grep Installed | sed 's/Installed://; s/\s*//'`
	[[ $ver && $ver != '(none)' ]] && echo 0 || echo 1
}

if [[ $(NeedToInstall libc6) -eq 1 ]]; then
	echo -e "> Install libc6"
	echo "deb http://cz.archive.ubuntu.com/ubuntu jammy main" >> /etc/apt/sources.list
	apt update
	apt install libc6 -yqq
else
	echo "${GREEN}> libc6 already installed${NOCOLOR}"
fi

nvmVersion=$(nvm --version 2>/dev/null)
if [[ ! $nvmVersion ]]; then
	echo -e "> Install nvm"
	curl -o- https://raw.githubusercontent.com/nvm-sh/nvm/v0.39.1/install.sh | bash

	export NVM_DIR="$([ -z "${XDG_CONFIG_HOME-}" ] && printf %s "${HOME}/.nvm" || printf %s "${XDG_CONFIG_HOME}/nvm")"
	[ -s "$NVM_DIR/nvm.sh" ] && \. "$NVM_DIR/nvm.sh"

	source ~/.bashrc
else
	echo "${GREEN}> nodejs already installed${NOCOLOR}"
fi

NODE_MAJOR=16
nvm install $NODE_MAJOR
nvm use $NODE_MAJOR

if [[ $(NeedToInstall git) -eq 1 ]]; then
	echo "> Install git"
	apt install -yqq git
else
	echo "${GREEN}> git already installed${NOCOLOR}"
fi

dir=/hive/miners/custom/quark-miner/miner
if [[ ! -d $dir/.git ]]; then
	echo "> git dir does not exist, cloning"
	git clone https://github.com/Frozenshift/quark_miner.git $dir

	cd $dir
	npm i
else
	echo "${GREEN}> git dir exist, just pull${NOCOLOR}"
	cd $dir
	git pull
	npm i
fi

cd ..
fileToReplace='pow-miner-cuda'
[[ -f $fileToReplace ]] && cp $fileToReplace $dir/$fileToReplace

echo "${GREEN}> install script complete${NOCOLOR}"

