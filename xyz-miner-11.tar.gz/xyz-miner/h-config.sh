#!/usr/bin/env bash
# This code is included in /hive/bin/custom function

[[ -z $CUSTOM_URL ]] && echo "CUSTOM_URL is empty" && return 1
[[ -z $CUSTOM_TEMPLATE ]] && echo -e "${YELLOW}CUSTOM_TEMPLATE is empty${NOCOLOR}" && return 1

# Wallet/address comes from flight sheet template field.
conf="--host ${CUSTOM_URL}"
conf+=" --user ${CUSTOM_TEMPLATE}"
conf+=" ${CUSTOM_USER_CONFIG}"

[[ -z $CUSTOM_CONFIG_FILENAME ]] && echo -e "${RED}No CUSTOM_CONFIG_FILENAME is set${NOCOLOR}" && return 1
echo "$conf" > "$CUSTOM_CONFIG_FILENAME"
