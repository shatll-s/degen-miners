#!/usr/bin/env bash

####################################################################################
###
### ninjarig-hash-layer
### Hive integration: shatll
###
####################################################################################

miner=ninjarig-hash-layer
. /hive/miners/custom/$miner/h-manifest.conf

algo=blake2b

# Get stats from ninjarig API
stats_raw=`curl -s --connect-timeout 3 --max-time 5 http://127.0.0.1:$API_PORT/summary`

if [[ -n $stats_raw && $stats_raw != *"curl: ("* ]]; then
	# Extract miner info
	miner_ver=$(echo "$stats_raw" | jq -r '.version // empty')
	uptime=$(echo "$stats_raw" | jq -r '.connection.uptime // 0')

	# Get total shares
	total_share=$(echo "$stats_raw" | jq -r '.results.shares_good // 0')
	total_badshare=$(echo "$stats_raw" | jq -r '(.results.shares_total // 0) - (.results.shares_good // 0)')

	# Get GPU count from API
	gpuCount=$(echo "$stats_raw" | jq -r '.hashers | length')

	busid_json='[]'
	fan_json='[]'
	temp_json='[]'
	declare -a hr_data=()

	# Read HiveOS GPU stats
	readarray -t gpu_stats < <( jq --slurp -r -c '.[] | .brand, .temp, .fan, .busids | join(" ")' $GPU_STATS_JSON 2>/dev/null)
	brands=(${gpu_stats[0]})
	temps=(${gpu_stats[1]})
	fans=(${gpu_stats[2]})
	busids=(${gpu_stats[3]})

	# Check if first device is CPU
	[[ ${brands[0]} == 'cpu' ]] && internalCpuShift=1 || internalCpuShift=0

	# Process each GPU from ninjarig API
	for (( i=0; i < gpuCount; i++ )); do
		# Get hashrate from ninjarig (in H/s)
		rawHr=$(echo "$stats_raw" | jq -r ".hashers[$i].hashrate[0] // 0")

		# Convert to MH/s
		hr=$(echo "scale=2; $rawHr / 1000000" | bc -l)
		hr_data+=($hr)

		# Map to HiveOS GPU stats
		y=$((i + internalCpuShift))

		# Get bus ID and convert format
		busid=${busids[$y]}
		b=$(echo $busid | awk -F ':' '{print $1}')

		# Convert hex to decimal for HiveOS
		busidHex=$(echo $b | tr '[:lower:]' '[:upper:]')
		[[ ${busidHex:0:1} == 0 ]] && busidHex=${busidHex:1:2}
		busidDecimal=$(echo "ibase=16; $busidHex" | bc)

		busid_json=$(jq ". += [\"$busidDecimal\"]" <<< "$busid_json")
		fan_json=$(jq ". += [\"${fans[$y]}\"]" <<< "$fan_json")
		temp_json=$(jq ". += [\"${temps[$y]}\"]" <<< "$temp_json")
	done

	# Convert arrays to JSON
	hr_json=$(printf '%s\n' "${hr_data[@]}" | jq -R . | jq -s .)

	# Calculate total hashrate
	totalHr=0
	for hr in "${hr_data[@]}"; do
		totalHr=$(echo "$totalHr + $hr" | bc)
	done
	totalKhs=$(echo "scale=0; $totalHr * 1000 / 1" | bc -l)

	# Compile stats for HiveOS
	stats=$(jq -nc \
		--arg algo "$algo" \
		--arg ver "${miner_ver:-$CUSTOM_VERSION}" \
		--arg uptime "$uptime" \
		--argjson hs "$hr_json" \
		--arg hs_units "mhs" \
		--arg ths "$totalKhs" \
		--argjson bus_numbers "$busid_json" \
		--argjson fan "$fan_json" \
		--argjson temp "$temp_json" \
		--arg ar "$total_share" \
		--arg rj "$total_badshare" \
		'{ $hs, $ths, $hs_units, $algo, $ver, $uptime, $bus_numbers, $fan, $temp, $ar, $rj }')

	khs=$totalHr
else
	khs=0
	stats="null"
fi

# Debug output
echo Log file : $CUSTOM_LOG_BASENAME.log
echo KHS : $khs
echo Output : $stats

[[ -z $khs ]] && khs=0
[[ -z $stats ]] && stats="null"
