#!/usr/bin/env bash

####################################################################################
###
### ninjarig-hash-layer miner for Feeless
### Hive integration: shatll
###
####################################################################################

miner='ninjarig-hash-layer'
[[ -e /hive/custom ]] && . /hive/custom/$miner/h-manifest.conf
[[ -e /hive/miners/custom ]] && . /hive/miners/custom/$miner/h-manifest.conf

conf=
conf+=" -o ${CUSTOM_URL} -u ${CUSTOM_TEMPLATE}"
conf+=" --api-port $API_PORT"
conf+=" ${CUSTOM_USER_CONFIG}"

[[ "conf" != *"-a"* ]] && conf+=" -a hashlayer" # default algo

echo -e "$conf" > $CUSTOM_CONFIG_FILENAME