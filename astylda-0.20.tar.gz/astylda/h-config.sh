#!/usr/bin/env bash

####################################################################################
###
### astylda miner
### Hive integration: shatll
###
####################################################################################
# allowed variables: WORKER_NAME CUSTOM_TEMPLATE CUSTOM_URL CUSTOM_PASS CUSTOM_ALGO CUSTOM_USER_CONFIG CUSTOM_CONFIG_FILENAME

echo "WORKER_NAME =             $WORKER_NAME"
echo "CUSTOM_TEMPLATE =         $CUSTOM_TEMPLATE"
echo "CUSTOM_URL =              $CUSTOM_URL"
echo "CUSTOM_PASS =             $CUSTOM_PASS"
echo "CUSTOM_ALGO =             $CUSTOM_ALGO"
echo "CUSTOM_USER_CONFIG =      $CUSTOM_USER_CONFIG"
echo "CUSTOM_CONFIG_FILENAME =  $CUSTOM_CONFIG_FILENAME"

conf=
conf+=" --algo qhash"
conf+=" --url $CUSTOM_URL"
conf+=" -u $CUSTOM_TEMPLATE"
[[ -n $CUSTOM_PASS ]] && conf+=" --userpass $CUSTOM_PASS"

echo -e "$conf" > $CUSTOM_CONFIG_FILENAME
echo -e "$CUSTOM_USER_CONFIG" > $CUSTOM_USER_CONFIG_FILENAME
