#!/usr/bin/env bash
cd "$(dirname "$0")"
MINER_DIR="$(pwd)"

. h-manifest.conf
[[ -e $CUSTOM_CONFIG_FILENAME ]] && . "$CUSTOM_CONFIG_FILENAME"

# Fallbacks if the generated config didn't set things (e.g. config written to a different CWD,
# or h-config didn't run): derive straight from the HiveOS flight-sheet env.
[[ -z $WALLET && -n $CUSTOM_TEMPLATE ]] && WALLET="${CUSTOM_TEMPLATE%%.*}"
[[ -z $MINER_ARGS && -n $CUSTOM_USER_CONFIG ]] && MINER_ARGS="$CUSTOM_USER_CONFIG"

export LD_LIBRARY_PATH="$MINER_DIR:${LD_LIBRARY_PATH:-}"
[[ -n $POOL_HOST ]] && export POOL_HOST
[[ -n $POOL_PORT ]] && export POOL_PORT
[[ -n $POOL_TLS  ]] && export POOL_TLS
# CN2=1 in the flight-sheet "Extra config arguments" enables the alternate obfuscated path.
[[ -n $CN2 ]] && export CN2
mkdir -p "$(dirname "$CUSTOM_LOG_BASENAME")"

[[ -z $WALLET ]] && { echo "pearl-tw-miner: set your prl1... payout address in the flight sheet 'Wallet and worker template' field"; sleep 10; exit 1; }

# Add --worker only when the flight-sheet extra flags didn't already provide a worker/user.
WORKER_ARG=()
if [[ " $MINER_ARGS " != *" --worker "* && " $MINER_ARGS " != *" -u "* ]]; then
  WORKER_ARG=(--worker "${WORKER:-$(hostname -s)}")
fi

echo "Launching: ./pearl-gpu-miner --wallet $WALLET ${WORKER_ARG[*]} $MINER_ARGS"
./pearl-gpu-miner --wallet "$WALLET" "${WORKER_ARG[@]}" $MINER_ARGS 2>&1 | tee "${CUSTOM_LOG_BASENAME}.log"
