#!/usr/bin/env bash

####################################################################################
###
### xelis miner
### Hive integration: shatll
###
####################################################################################

[[ -e /hive/custom ]] && . /hive/custom/xelis-miner/h-manifest.conf
[[ -e /hive/miners/custom ]] && . /hive/miners/custom/xelis-miner/h-manifest.conf

conf="--host ${CUSTOM_URL} --wallet ${CUSTOM_TEMPLATE} ${CUSTOM_USER_CONFIG}"
[[ "conf" != *"--display-hs-all"* ]] && conf+=" --display-hs-all"
echo -e "$conf" > $CUSTOM_CONFIG_FILENAME
