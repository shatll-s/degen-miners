#!/usr/bin/env bash

####################################################################################
###
### upowai miner
### Hive integration: shatll
###
####################################################################################

[[ -e /hive/custom ]] && . /hive/custom/upowai-miner/h-manifest.conf
[[ -e /hive/miners/custom ]] && . /hive/miners/custom/upowai-miner/h-manifest.conf

/hive/miners/custom/upowai-miner/install.sh

conf="--address ${CUSTOM_TEMPLATE} ${CUSTOM_USER_CONFIG}"
[[ "conf" != *"--device"* ]] && conf+=" --device $(gpu-detect NVIDIA)}"
echo -e "$conf" > $CUSTOM_CONFIG_FILENAME
