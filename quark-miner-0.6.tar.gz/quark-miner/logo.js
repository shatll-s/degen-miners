import { sleep } from "../utils/utils.js";

export const logo = async (logger) => {
    await sleep(150);
    logger.info(` `);
    await sleep(150);
    logger.info(` #######   ##     ##     ###     ########   ##    ##`);
    await sleep(150);
    logger.info(`##     ##  ##     ##    ## ##    ##     ##  ##   ##`);
    await sleep(150);
    logger.info(`##     ##  ##     ##   ##   ##   ##     ##  ##  ##`);
    await sleep(150);
    logger.info(`##     ##  ##     ##  ##     ##  ########   #####`);
    await sleep(150);
    logger.info(`##  ## ##  ##     ##  #########  ##   ##    ##  ##`);
    await sleep(150);
    logger.info(`##    ##   ##     ##  ##     ##  ##    ##   ##   ##`);
    await sleep(150);
    logger.info(` ##### ##   #######   ##     ##  ##     ##  ##    ##`);
    await sleep(150);
    logger.info(` `);
};