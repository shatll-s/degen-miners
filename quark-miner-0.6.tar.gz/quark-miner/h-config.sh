#!/usr/bin/env bash

####################################################################################
###
### QUARK miner
### Hive integration: shatll
###
####################################################################################

[[ -e /hive/custom ]] && . /hive/custom/quark-miner/h-manifest.conf
[[ -e /hive/miners/custom ]] && . /hive/miners/custom/quark-miner/h-manifest.conf

/hive/miners/custom/quark-miner/install.sh

userCfg=""

conf="SEED=$CUSTOM_TEMPLATE"
conf+="\nGPU__VENDOR=NVIDIA"
[[ ! -z $CUSTOM_USER_CONFIG ]] && userCfg+=" $CUSTOM_USER_CONFIG"

if [[ "$userCfg" == *"--uuid"* ]]; then
  uuid=`echo $userCfg | sed -e 's/.*--uuid //; s/ .*//'`
  [[ $uuid ]] && conf+="\nUUID=$uuid"
  userCfg=`echo "$userCfg" | sed -e "s/--uuid $uuid//"`
fi

[[ "$@" != *"--gpu-count"* ]] && conf+="\nGPU__COUNT=$(gpu-detect NVIDIA)"

[[ $CUSTOM_PASS ]] && conf+="\nTONAPI_TOKEN=$CUSTOM_PASS"
echo -e "$conf" > $CUSTOM_CONFIG_FILENAME


