#!/usr/bin/env bash

####################################################################################
###
### astylda miner
### Hive integration: shatll
###
####################################################################################
# allowed variables: WORKER_NAME CUSTOM_TEMPLATE CUSTOM_URL CUSTOM_PASS CUSTOM_ALGO CUSTOM_CONFIG_FILENAME

echo "WORKER_NAME =             $WORKER_NAME"
echo "CUSTOM_TEMPLATE =         $CUSTOM_TEMPLATE"
echo "CUSTOM_URL =              $CUSTOM_URL"
echo "CUSTOM_PASS =             $CUSTOM_PASS"
echo "CUSTOM_ALGO =             $CUSTOM_ALGO"
echo "CUSTOM_CONFIG_FILENAME =  $CUSTOM_CONFIG_FILENAME"

conf=
conf+=" --algo qhash"
conf+=" --url $CUSTOM_URL"
conf+=" --coinbase-addr $CUSTOM_TEMPLATE"
conf+=" --userpass $CUSTOM_PASS"

echo -e "$conf" > $CUSTOM_CONFIG_FILENAME
